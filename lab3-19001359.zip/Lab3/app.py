from flask import Flask, request, jsonify
import json
import collections
import hashlib
from datetime import datetime

import DBController as DBC

app = Flask(__name__)

#1
@app.route('/newUser', methods=['POST'])
def create_new_user():
    try:
        data = request.get_json()
        print(data['username'])
        dbConnection = DBC.dbController('127.0.0.1', 3306, 'rihanna1', 'root', 'tienda')
        
        #encripcion del password.
        usPass = hashlib.md5(data['password'].encode('utf-8'))
        usNameEncode = hashlib.md5(data['username'].encode('utf-8'))
        usPassEncode = (usNameEncode.hexdigest() + usPass.hexdigest()).encode('utf-8')
        encriptedPass = (hashlib.md5(usPassEncode).hexdigest())
        print(encriptedPass)
        print(data['email'])
        #insertamos fecha con formato de SQL
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
        
        dbConnection.insertNewUser(data['username'], encriptedPass, data['email'],now)
        return jsonify({'menssage': 'Usuario Creado'})
    except Exception as ex:
        print(ex)
        return jsonify({'menssage': 'Ocurrio un error.'})

#2
@app.route('/setinfoUser/<userId>', methods=['PUT'])
def update_info_user(userId):
    try:
        data = request.get_json()
        dbConnection = DBC.dbController('127.0.0.1', 3306, 'rihanna1', 'root', 'tienda')

         #encripcion del password.
        usPass = hashlib.md5(data['newPassword'].encode('utf-8'))
        usNameEncode = hashlib.md5(data['newuserName'].encode('utf-8'))
        usPassEncode = (usNameEncode.hexdigest() + usPass.hexdigest()).encode('utf-8')
        encriptedPass = (hashlib.md5(usPassEncode).hexdigest())
        print(encriptedPass)


        dbConnection.updateUser(data['newuserName'], encriptedPass, data['newEmail'], userId)
        return jsonify({'message': 'Datos Actualizados Exitosamente.'})
    except Exception as ex:
        print(ex)
        return jsonify({'message': 'Ocurrio un error.'})


#3
@app.route('/infoUser', methods=['POST'])
def info_user():
    try:
        data = request.get_json()
        dbConnection = DBC.dbController('127.0.0.1', 3306, 'rihanna1', 'root', 'tienda')
        salida = dbConnection.getUser(data['username'])
        return jsonify(salida)
    except Exception as ex:
        print(ex)
        return jsonify({'message': 'Ocurrio un error.'})

#4
@app.route('/infoPurchase', methods=['POST'])
def info_purchase():
    try:
        data = request.get_json()
        dbConnection = DBC.dbController('127.0.0.1', 3306, 'rihanna1', 'root', 'tienda')
        salida = dbConnection.getPurchase(data['username'])
        return jsonify(salida)
    except Exception as ex:
        print(ex)
        return jsonify({'message': 'Ocurrio un error.'})

#5
@app.route('/newPurchase', methods=['POST'])
def create_new_Purchase():
    try:
        data = request.get_json()
        dbConnection = DBC.dbController('127.0.0.1', 3306, 'rihanna1', 'root', 'tienda')
        
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
        dbConnection.insertNewPurchase(data['totalCompra'], data['userId'], now, data['idCompra'], data['idProducto'], data['cantidadComprada'], data['precioUnitario'], data['subTotal'])
        return jsonify({'menssage': 'Compra Creado'})
    except Exception as ex:
        print(ex)
        return jsonify({'menssage': 'Ocurrio un error.'})


#6
@app.route('/infoPurchaseDate', methods=['POST'])
def info_purchase_date():
    try:
        data = request.get_json()
        dbConnection = DBC.dbController('127.0.0.1', 3306, 'rihanna1', 'root', 'tienda')
        salida = dbConnection.getPurchaseDate(data['range1'], data['range2'])
        return jsonify(salida)
    except Exception as ex:
        print(ex)
        return jsonify({'message': 'Ocurrio un error.'})

#7
@app.route('/infoPurchaseTotal', methods=['POST'])
def info_purchase_total():
    try:
        data = request.get_json()
        dbConnection = DBC.dbController('127.0.0.1', 3306, 'rihanna1', 'root', 'tienda')
        salida = dbConnection.getPurchaseTotal(data['total1'], data['total2'])
        return jsonify(salida)
    except Exception as ex:
        print(ex)
        return jsonify({'message': 'Ocurrio un error.'})

#8
@app.route('/allProducts', methods=['GET'])
def get_all_products():
    try:
        dbConnection = DBC.dbController('127.0.0.1', 3306, 'rihanna1', 'root', 'tienda')
        salida = dbConnection.getAllProducts()
        return jsonify(salida)
    except Exception as ex:
        print(ex)
        return jsonify({'message': 'Ocurrio un error.'})


#9
@app.route('/setTotalPurchase/<PurchaseId>', methods=['PUT'])
def update_total_purchase(PurchaseId):
    try:
        data = request.get_json()
        dbConnection = DBC.dbController('127.0.0.1', 3306, 'rihanna1', 'root', 'tienda')
        dbConnection.updatePurchase(data['newTotal'], PurchaseId)
        return jsonify({'message': 'Datos Actualizados Exitosamente.'})
    except Exception as ex:
        print(ex)
        return jsonify({'message': 'Ocurrio un error.'})

#10
@app.route('/setPurchaseDetail/<PurchaseDetailId>', methods=['PUT'])
def update_purchase_detail(PurchaseDetailId):
    try:
        data = request.get_json()
        dbConnection = DBC.dbController('127.0.0.1', 3306, 'rihanna1', 'root', 'tienda')
        dbConnection.updatePurchaseDetail(data['newQuantity'], data['newPrice'], PurchaseDetailId)
        return jsonify({'message': 'Datos Actualizados Exitosamente.'})
    except Exception as ex:
        print(ex)
        return jsonify({'message': 'Ocurrio un error.'})


if(__name__ == '__main__'):
    app.run(debug=True)
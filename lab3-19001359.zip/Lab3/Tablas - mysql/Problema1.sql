Create database tienda;

Use tienda;

Create Table Usuarios(
    id int PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50),
    password VARCHAR(50),
    email VARCHAR(60),
    creationDate DATETIME
);

Create Table Compras(
    id int PRIMARY KEY AUTO_INCREMENT,
    totalCompra varchar(10),
    userId int,
    fechaHoraCompra DATETIME,

    CONSTRAINT FK_userId FOREIGN KEY (userId)
                    REFERENCES usuarios(Id)
);

Create Table Productos(
    id int PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50),
    precio varchar(10)
);

Create Table DetallesCompra(
    id int PRIMARY KEY AUTO_INCREMENT,
    idCompra int,
    idProducto int,
    cantidadComprada int,
    precioUnitario varchar(10),
    subTotal varchar(10),

    CONSTRAINT FK_idCompra FOREIGN KEY (idCompra)
                    REFERENCES Compras(Id),

    CONSTRAINT FK_idProducto FOREIGN KEY (idProducto)
                    REFERENCES Productos(Id)
);


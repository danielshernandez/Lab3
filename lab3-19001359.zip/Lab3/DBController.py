import pymysql
import hashlib
from datetime import datetime

class dbController:
    def __init__(self, hostIP, hostPort, hostPass, dbUser, dbName):
        #atributos
        self.host = hostIP
        self.port = hostPort
        self.username = dbUser
        self.db = dbName
        self.password = hostPass
        self.connection = pymysql.connect(
            host=self.host,
            port=self.port,
            user=self.username,
            password=self.password,
            db=self.db
        )
        self.cursor = self.connection.cursor()

    #1
    def insertNewUser(self, usName, usPass, usEmail, now):
        sql = "INSERT INTO Usuarios (username, password, email, creationDate) VALUES (%s, %s, %s, %s)"
        self.cursor.execute(sql, (usName, usPass, usEmail, now))
        self.connection.commit()
        self.dbCloseConnection()

    #2
    def updateUser(self, usName, usPass, usEmail, userId):
        sql = "UPDATE Usuarios SET username = %s , password= %s, email= %s where id = %s"
        self.cursor.execute(sql, (usName, usPass, usEmail, userId))
        self.connection.commit()
        self.dbCloseConnection()

    #3
    def getUser(self, usName):
        sql = "SELECT * FROM usuarios WHERE username = %s"
        self.cursor.execute(sql, usName)
        rows = self.cursor.fetchall()
        self.dbCloseConnection()
        return rows

    #4
    def getPurchase(self, usName):
        sql = "SELECT C.id AS IdCompra, C.totalCompra, C.fechaHoraCompra  FROM compras AS C INNER JOIN usuarios AS U ON C.userId=U.id WHERE username = %s"
        self.cursor.execute(sql, usName)
        rows = self.cursor.fetchall()
        self.dbCloseConnection()
        return rows

    #5
    def insertNewPurchase(self, pcTotal, usId, pcDate, pdPurchaseId, pdProductId, pdQuantity, pdPrice, pdTotal):
        sql = "INSERT INTO compras (totalCompra, userId, fechaHoraCompra) VALUES (%s, %s, %s)"
        sql1 = "INSERT INTO DetallesCompra (idCompra, idProducto, cantidadComprada, precioUnitario, subTotal) VALUES (%s, %s, %s, %s, %s)"
        self.cursor.execute(sql, (pcTotal, usId, pcDate))
        self.cursor.execute(sql1, (pdPurchaseId, pdProductId, pdQuantity, pdPrice, pdTotal))
        self.connection.commit()
        self.dbCloseConnection()

    #6
    def getPurchaseDate(self, limit1, limit2):
        sql = "SELECT * FROM compras WHERE (YEAR(fechaHoraCompra) >= %s and YEAR(fechaHoraCompra) <= %s)"
        self.cursor.execute(sql, (limit1, limit2))
        rows = self.cursor.fetchall()
        self.dbCloseConnection()
        return rows

    #7
    def getPurchaseTotal(self, limit1, limit2):
        sql = "SELECT * FROM compras WHERE (totalCompra >= %s and totalCompra <= %s)"
        self.cursor.execute(sql, (limit1, limit2))
        rows = self.cursor.fetchall()
        self.dbCloseConnection()
        return rows

    #8
    def getAllProducts(self):
        self.cursor.execute("SELECT id, nombre, precio FROM Productos")
        rows = self.cursor.fetchall()
        return rows

    #9
    def updatePurchase(self, pcTotal, userId):
        sql = "UPDATE compras SET totalCompra = %s where id = %s"
        self.cursor.execute(sql, (pcTotal,userId))
        self.connection.commit()
        self.dbCloseConnection()

    #10
    def updatePurchaseDetail(self, dtQuantity, dtPrice, dtId):
        sql = "UPDATE DetallesCompra SET cantidadComprada = %s, precioUnitario = %s where id = %s"
        self.cursor.execute(sql, ( dtQuantity, dtPrice, dtId))
        self.connection.commit()
        self.dbCloseConnection()

    def dbCloseConnection(self):
        self.connection.close()